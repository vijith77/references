(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.parallax').parallax();
    $('.tap-target').tapTarget();

  }); // end of document ready
})(jQuery); // end of jQuery name space
